import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function BriefModal({ open, onOpenChange, icon, header, subheader, introText, bodyText }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center text-2xl font-bold">
            {icon && <span className="mr-2">{icon}</span>}
            {header}
          </DialogTitle>
          {subheader && <p className="text-lg text-muted-foreground">{subheader}</p>}
        </DialogHeader>
        <ScrollArea className="mt-4 max-h-[60vh]">
          <div className="space-y-4 p-4">
            {introText && <p className="text-lg">{introText}</p>}
            <div className="prose max-w-none">
              {bodyText}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}

