'use client'

import Image from 'next/image'
import Link from 'next/link'

interface AgentCard {
  category: string
  title: string
  image: string
  readTime?: string
  href: string
}

const agents: AgentCard[] = [
  {
    category: "Build Agent",
    title: "Smart Contract Builder: Privacy-First DeFi Solutions",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "5 min setup",
    href: "#"
  },
  {
    category: "Create Agent",
    title: "AI Music Composer: Web3 Rights Management",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "3 min setup",
    href: "#"
  },
  {
    category: "Learn Agent",
    title: "COTI Documentation Navigator",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "2 min setup",
    href: "#"
  },
  {
    category: "Launch Agent",
    title: "Community Event Coordinator",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "4 min setup",
    href: "#"
  },
  {
    category: "Teach Agent",
    title: "Privacy on Demand helper. Garble data from Solana.",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "6 min setup",
    href: "#"
  },
  {
    category: "Ideate Agent",
    title: "Privacy-First Project Generator",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "3 min setup",
    href: "#"
  },
  {
    category: "Host Agent",
    title: "Community Meetup Organizer",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "5 min setup",
    href: "#"
  },
  {
    category: "Research Agent",
    title: "Web3 Privacy Trends Analyzer",
    image: "/placeholder.svg?height=400&width=300",
    readTime: "4 min setup",
    href: "#"
  }
]

export default function AgentGrid() {
  return (
    <section className="w-full bg-black py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Community Led Agents
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Build, mint, create, learn, launch, teach, ideate, host... chose your verb and explore community built agents that may get you further faster.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {agents.map((agent, index) => (
            <Link 
              key={index} 
              href={agent.href}
              className="group block relative w-full aspect-[3/4] rounded-xl overflow-hidden hover:transform hover:scale-[1.02] transition-transform duration-200"
            >
              <Image
                src={agent.image}
                alt={agent.title}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/65 to-black/20" />
              
              <div className="absolute inset-0 p-6 flex flex-col justify-between">
                <div className="text-sm font-medium text-white/90">
                  {agent.category}
                </div>
                
                <div className="space-y-2">
                  {agent.readTime && (
                    <div className="text-sm text-white/75">
                      {agent.readTime}
                    </div>
                  )}
                  <h3 className="text-xl font-semibold text-white group-hover:underline decoration-1 underline-offset-2">
                    {agent.title}
                  </h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

