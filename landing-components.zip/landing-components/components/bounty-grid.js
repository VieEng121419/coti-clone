'use client'

import { useState, useEffect, useCallback } from 'react'
import { Lightbulb, FileText, ArrowRight, ThumbsUp } from 'lucide-react'
import IdeasModal from './ideas-modal'
import BriefModal from './brief-modal'
import UpvoteModal from './upvote-modal' // Import UpvoteModal
import { ideasData } from '../data/ideas-data'
import { briefData } from '../data/brief-data'

const bounties = [
  {
    type: "BUILD",
    title: "Build a Medical Data App",
    description: "Create a secure, privacy-focused application for managing and sharing medical data using our SDK.",
    metric: "Reward Pool",
    value: "$3,000",
    bgColor: "bg-emerald-100"
  },
  {
    type: "INTEGRATE",
    title: "Integrate Avae w/ COTI",
    description: "Build the integration between Avae's existing infrastructure and COTI's privacy framework.",
    metric: "Reward Pool",
    value: "$35,000",
    bgColor: "bg-black text-white"
  },
  {
    type: "CREATION SQUAD",
    title: "Launch a Private AI Music Album w/ 20K Streams",
    description: "Use AI to generate unique music while maintaining creator privacy and rights management.",
    metric: "Reward Pool",
    value: "$250",
    bgColor: "bg-purple-200"
  },
  {
    type: "BUILD",
    title: "Create a Private Metadata NFT project",
    description: "Design and launch a privacy-preserving NFT collection with built-in royalty distribution.",
    metric: "Reward Pool",
    value: "$2,500",
    bgColor: "bg-yellow-100"
  },
  {
    type: "RESEARCH",
    title: "Web3 Privacy Solutions Report",
    description: "Create comprehensive industry analysis of current web3 privacy solutions and future trends.",
    metric: "Reward Pool",
    value: "$1,500",
    bgColor: "bg-blue-100"
  },
  {
    type: "COMMUNITY",
    title: "Build Party in Tokyo",
    description: "Organize and host a builder-focused event in Tokyo to expand our Asia presence.",
    metric: "Reward Pool",
    value: "$1,250",
    bgColor: "bg-pink-100"
  },
  {
    type: "GROWTH",
    title: "Community Expansion",
    description: "Strategic initiative to grow our community with focus on developers and creators.",
    metric: "Reward Pool",
    value: "$500",
    bgColor: "bg-orange-100"
  },
  {
    type: "CONTENT",
    title: "Privacy in AI Interview Series",
    description: "Create a series of thought leadership interviews with AI industry leaders.",
    metric: "Reward Pool",
    value: "$1,000",
    bgColor: "bg-indigo-100"
  },
  {
    type: "BUILD",
    title: "Privacy-First Social Platform",
    description: "Develop a social media platform with built-in privacy features using COTI framework.",
    metric: "Reward Pool",
    value: "$12,000",
    bgColor: "bg-teal-100"
  }
]

export default function BountyGrid() {
  const [selectedBounty, setSelectedBounty] = useState(null)
  const [selectedBrief, setSelectedBrief] = useState(null)
  const [isUpvoteModalOpen, setIsUpvoteModalOpen] = useState(false) // Add UpvoteModal state
  const [selectedProjectTitle, setSelectedProjectTitle] = useState(null); //Update 1

  const handleIdeaClick = (bountyTitle) => {
    if (ideasData[bountyTitle]) {
      setSelectedBounty(bountyTitle)
    }
  }

  const handleBriefClick = (bountyTitle) => {
    if (briefData[bountyTitle]) {
      setSelectedBrief(bountyTitle);
      console.log('Opening brief for:', bountyTitle); // Add this debug log
    } else {
      console.log('No brief data found for:', bountyTitle); // Add this debug log
    }
  }

  const handleUpvoteClick = useCallback((title) => { // Update 2
    console.log('Upvote button clicked for:', title); // Update 2
    setSelectedProjectTitle(title); // Update 2
    setIsUpvoteModalOpen(true); // Update 2
  }, []); // Update 2

  const selectedBountyData = selectedBounty ? ideasData[selectedBounty] : null
  const selectedBriefData = selectedBrief ? briefData[selectedBrief] : null

  useEffect(() => {
    console.log('Available bounties:', Object.keys(ideasData)) // Debug log
    console.log('Available briefs:', Object.keys(briefData)); // Add this debug log
  }, [])

  return (
    <section className="py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          <span className="gradient-text">WAGMI Projects</span>
        </h2>
        <p className="text-gray-600 max-w-4xl mx-auto text-center mb-12">
          Getting rewarded in Web3 isn't just for the devs and VCs anymore. COTI belongs to us. Together, we're bringing back WAGMI, community creation, building, ideation, and inspiration. Everyone supporting the COTI community has the opportunity to build, create, evangelize, and benefit. We build out loud and use COTI resources to promote, unblock, and elevate the best community ideas, projects, meetups, campaigns, and creations. Choose an activity below, and get started.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bounties.map((bounty, index) => (
            <div 
              key={index}
              className={`${bounty.bgColor} rounded-xl p-6 flex flex-col justify-between h-full`}
            >
              <div className="space-y-4 flex-1">
                <div className="text-sm font-medium tracking-wide opacity-80">
                  {bounty.type}
                </div>
                
                <h3 className="font-bold text-2xl">{bounty.title}</h3>
                
                <p className="text-sm opacity-80">
                  {bounty.description}
                </p>
              </div>

              <div className="pt-4 border-t border-black/10 mt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs opacity-70">{bounty.metric}</div>
                    <div className="font-bold">{bounty.value}</div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={() => handleIdeaClick(bounty.title)}
                      className="flex items-center gap-2 text-sm font-medium hover:opacity-70"
                    >
                      <Lightbulb size={18} />
                      Ideas
                    </button>
                    <button 
                      onClick={() => handleBriefClick(bounty.title)}
                      className="flex items-center gap-2 text-sm font-medium hover:opacity-70"
                    >
                      <FileText size={18} />
                      Brief
                    </button>
                    <button 
                      onClick={() => handleUpvoteClick(bounty.title)} // Update 3
                      className="flex items-center gap-2 text-sm font-medium hover:opacity-70"
                    >
                      <ThumbsUp size={18} />
                      Upvote
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedBountyData && (
        <IdeasModal 
          open={!!selectedBounty}
          onOpenChange={() => setSelectedBounty(null)}
          title={selectedBountyData.title}
          description={selectedBountyData.description}
          data={selectedBountyData.data}
        />
      )}

      {selectedBrief && (
        <BriefModal
          open={!!selectedBrief}
          onOpenChange={() => setSelectedBrief(null)}
          icon={<FileText className="w-6 h-6" />}
          header={briefData[selectedBrief].header}
          subheader={briefData[selectedBrief].subheader}
          introText={briefData[selectedBrief].introText}
          bodyText={briefData[selectedBrief].bodyText}
        />
      )}
      <UpvoteModal // Update 4
        open={isUpvoteModalOpen}
        onOpenChange={(open) => {
          console.log('UpvoteModal onOpenChange:', open); // Add this debug log
          setIsUpvoteModalOpen(open);
        }}
        projectTitle={selectedProjectTitle} // Update 4
      /> {/* Add UpvoteModal */}
    </section>
  )
}

