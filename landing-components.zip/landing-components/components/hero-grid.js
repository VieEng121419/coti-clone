import React, { useRef, useEffect, useState, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text } from '@react-three/drei'
import * as THREE from 'three'

const allSymbols = [
  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
  'A', 'B', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
  'N', 'P', 'Q', 'R', 'S', 'U', 'V', 'W', 'X', 'Y', 'Z',
  '○', '□', '△', '◇', '⬟', '⬢', '⬡', '⯃', '⯂', '▲', '▼', '◀',
  '+', '-', '×', '÷', '=', '<', '>', '?', '!', '@', '#', '$', '%', '&'
]
const staticSymbols = ['0', '1']
const cotiLetters = ['C', 'O', 'T', 'I']

function HeroGrid({ rows = 20, cols = 48, isMouseMoving }) {
  const meshRef = useRef()
  const [gridData, setGridData] = useState([])
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)
  const [isTablet, setIsTablet] = useState(window.innerWidth >= 768 && window.innerWidth < 1024)
  const [lastStaticGrid, setLastStaticGrid] = useState(null)

  const fontSize = useMemo(() => {
    if (isMobile) return 0.32
    if (isTablet) return 0.4  // Increased from 0.32 to 0.4 (25% increase)
    return 1.008
  }, [isMobile, isTablet])

  const spacing = useMemo(() => {
    if (isMobile) return 1.1
    if (isTablet) return 1.3
    return 1.5
  }, [isMobile, isTablet])

  const generateStaticGrid = () => {
    const newGridData = []
    const cotiPositions = []

    for (let i = 0; i < rows; i += 3) {
      const cotiStart = Math.floor(Math.random() * (cols - 3))
      for (let j = 0; j < 4; j++) {
        cotiPositions.push({ row: i, col: cotiStart + j })
      }
    }

    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        const isCotiPosition = cotiPositions.some(pos => pos.row === i && pos.col === j)
        newGridData.push({
          position: [(j - cols / 2 + 0.5) * spacing, (rows / 2 - i - 0.5) * spacing, -2],
          symbol: isCotiPosition ? cotiLetters[cotiPositions.findIndex(pos => pos.row === i && pos.col === j) % 4] : staticSymbols[Math.floor(Math.random() * staticSymbols.length)],
          color: new THREE.Color(0x1a1a1a).lerp(new THREE.Color(0x333333), j / cols),
          isCoti: isCotiPosition
        })
      }
    }
    return newGridData
  }

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
      setIsTablet(window.innerWidth >= 768 && window.innerWidth < 1024)
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    setGridData(generateStaticGrid())
    setLastStaticGrid(generateStaticGrid())
  }, [rows, cols, spacing])

  useFrame(() => {
    if (isMouseMoving) {
      setGridData(prevData => {
        return prevData.map(cell => ({
          ...cell,
          symbol: allSymbols[Math.floor(Math.random() * allSymbols.length)]
        }))
      })
    } else if (gridData !== lastStaticGrid) {
      const newStaticGrid = generateStaticGrid()
      setGridData(newStaticGrid)
      setLastStaticGrid(newStaticGrid)
    }
  })

  return (
    <group ref={meshRef}>
      {gridData.map((cell, index) => (
        <Text
          key={index}
          position={cell.position}
          color={cell.color}
          fontSize={fontSize}
          anchorX="center"
          anchorY="middle"
          opacity={0.15}
        >
          {cell.symbol}
        </Text>
      ))}
    </group>
  )
}

export default HeroGrid

