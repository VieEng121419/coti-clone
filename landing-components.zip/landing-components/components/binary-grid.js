import React, { useRef, useEffect, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text } from '@react-three/drei'
import * as THREE from 'three'

const symbols = [
  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
  'A', 'B', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
  'N', 'P', 'Q', 'R', 'S', 'U', 'V', 'W', 'X', 'Y', 'Z',
  '○', '□', '△', '◇', '⬟', '⬢', '⬡', '⯃', '⯂', '▲', '▼', '◀',
  '+', '-', '×', '÷', '=', '<', '>', '?', '!', '@', '#', '$', '%', '&'
]
const cotiLetters = ['C', 'O', 'T', 'I']

function BinaryGrid({ rows = 7, cols = 8, globeRotation, isMouseMoving }) {
  const meshRef = useRef()
  const [gridData, setGridData] = useState([])

  useEffect(() => {
    const newGridData = []
    const spacing = 3.0
    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        const isCotiPosition = i === 3 && j >= 2 && j <= 5
        newGridData.push({
          position: [(j - cols / 2 + 0.5) * spacing, (rows / 2 - i - 0.5) * spacing, -2],
          symbol: isCotiPosition ? cotiLetters[j - 2] : symbols[Math.floor(Math.random() * symbols.length)],
          color: new THREE.Color(0x00ff00).lerp(new THREE.Color(0x0000ff), j / cols),
          isCoti: isCotiPosition
        })
      }
    }
    setGridData(newGridData)
  }, [rows, cols])

  useFrame(() => {
    if (isMouseMoving) {
      setGridData(prevData => {
        return prevData.map((cell, index) => {
          const rotationEffect = (globeRotation.x + globeRotation.y) * 2;
          const changeThreshold = Math.abs(rotationEffect) % 0.2;

          if (Math.random() < changeThreshold) {
            const newSymbol = cell.isCoti 
            ? symbols[Math.floor(Math.random() * symbols.length)]
            : symbols.filter(s => !cotiLetters.includes(s))[Math.floor(Math.random() * (symbols.filter(s => !cotiLetters.includes(s)).length))];
            return { ...cell, symbol: newSymbol };
          }
          return cell;
        });
      });
    } else {
      // When mouse stops, revert COTI letters
      setGridData(prevData => {
        return prevData.map((cell, index) => {
          if (cell.isCoti) {
            const col = index % cols;
            return { ...cell, symbol: cotiLetters[col - 2] };
          }
          return cell;
        });
      });
    }
  })

  return (
    <group ref={meshRef}>
      {gridData.map((cell, index) => (
        <Text
          key={index}
          position={cell.position}
          color={cell.color}
          fontSize={1.5}
          anchorX="center"
          anchorY="middle"
          opacity={0.3}
        >
          {cell.symbol}
        </Text>
      ))}
    </group>
  )
}

export default BinaryGrid

