'use client'

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { DiscIcon as Discord } from 'lucide-react'

const medicalIdeas = [
  {
    idea: "Develop a decentralized health records system that allows patients to securely share specific parts of their medical history with different healthcare providers while maintaining full control over their data.",
    tools: ["Supabase Starter", "HIPAA GPT", "v0.dev"],
  },
  {
    idea: "Create a privacy-focused telemedicine platform that enables secure video consultations and encrypted medical document sharing between patients and healthcare providers.",
    tools: ["Cursor", "HIPAA GPT", "Bolt.new"],
  },
  {
    idea: "Build a medical research data marketplace where institutions can securely share and monetize anonymized patient data while ensuring HIPAA compliance.",
    tools: ["MediBot", "Supabase Starter", "v0.dev"],
  },
  {
    idea: "Develop a patient-controlled health data wallet that uses blockchain technology to manage access permissions and track data usage.",
    tools: ["Cursor", "Supabase Starter", "HIPAA GPT"],
  },
  {
    idea: "Create a secure platform for clinical trial recruitment that matches patients with trials while protecting sensitive medical information.",
    tools: ["MediBot", "HIPAA GPT", "v0.dev"],
  },
  {
    idea: "Build a privacy-preserving health analytics platform that allows researchers to run queries on encrypted medical data without exposing raw information.",
    tools: ["Bolt.new", "Supabase Starter", "HIPAA GPT"],
  },
  {
    idea: "Develop a secure medical imaging sharing platform with built-in AI analysis capabilities while maintaining patient privacy.",
    tools: ["Cursor", "MediBot", "v0.dev"],
  },
  {
    idea: "Create a decentralized prescription management system that prevents fraud while protecting patient privacy.",
    tools: ["Supabase Starter", "HIPAA GPT", "Bolt.new"],
  },
  {
    idea: "Build a secure platform for sharing genetic testing results with family members while maintaining individual privacy preferences.",
    tools: ["MediBot", "v0.dev", "HIPAA GPT"],
  },
  {
    idea: "Develop a privacy-focused mental health data tracking app that allows selective sharing with healthcare providers.",
    tools: ["Cursor", "Bolt.new", "Supabase Starter"],
  }
]

export default function MedicalDataModal({ open, onOpenChange }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Medical Data App Ideas</DialogTitle>
          <DialogDescription className="text-lg">
            Explore potential projects that leverage COTI's privacy framework for healthcare
          </DialogDescription>
        </DialogHeader>
        
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50%]">Ideas</TableHead>
              <TableHead className="w-[35%]">Possible Tools</TableHead>
              <TableHead className="w-[15%]">Find Fellow Creators</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {medicalIdeas.map((item, index) => (
              <TableRow key={index}>
                <TableCell className="align-top">{item.idea}</TableCell>
                <TableCell className="align-top">
                  <div className="space-y-1">
                    {item.tools.map((tool, toolIndex) => (
                      <div key={toolIndex} className="inline-block mr-2 mb-2 px-2 py-1 bg-gray-100 rounded-md text-sm">
                        {tool}
                      </div>
                    ))}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center justify-center h-full">
                    <Button variant="outline" size="sm" className="gap-2">
                      <Discord className="w-4 h-4" />
                      Discord
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </DialogContent>
    </Dialog>
  )
}

