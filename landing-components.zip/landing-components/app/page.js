import Nav from '../components/nav'
import Hero from '../components/hero'
import VideoGrid from '../components/video-grid'
import CardGrid from '../components/card-grid'
import BountyGrid from '../components/bounty-grid'
import GlobeSection from '../components/globe-section'
import StatsGrid from '../components/stats-grid'
import AgentGrid from '../components/agent-grid'
import { PlaySquare, Code, Image, Users, Megaphone, PenToolIcon as Tool, Clipboard } from 'lucide-react'

export default function Home() {
  const videos = [
    {
      url: "https://www.youtube.com/watch?v=zA-eCGFBXjM",
      title: "COTI Build Stream: Privacy-First Social Media",
      description: "Watch our team build a decentralized social platform live!",
      award: 250
    },
    {
      url: "https://www.youtube.com/watch?v=i824zN0DGIo&list=PLifi2H-Dyi_pF2Dt6S2oNHEedaqZGc6L_&index=1",
      title: "Binary237's COTI Creatathon Event Dubai",
      description: "See the amazing projects from our latest hackathon",
      award: 200
    },
    {
      url: "https://www.youtube.com/watch?v=p09yRj47kNM",
      title: "COTI and Google: Live community strategy building",
      description: "Learn how to leverage Google AI's for your COTI meet-up planning.",
      award: 150
    },
    {
      url: "https://www.youtube.com/watch?v=NTLAuvfJwmE&list=PLifi2H-Dyi_pF2Dt6S2oNHEedaqZGc6L_&index=3",
      title: "COTI Bangalore Meet Up: Building with Claude",
      description: "Featuring the best projects from our builder community",
      award: 100
    }
  ]

  const cards = [
    {
      icon: <PlaySquare className="w-6 h-6 text-red-500" />,
      iconBg: "#fee2e2",
      title: "Get YouTube Transcript",
      description: "Fetch the transcript (subtitles / captions) of any YouTube video."
    },
    {
      icon: <Code className="w-6 h-6 text-yellow-500" />,
      iconBg: "#fef3c7",
      title: "Scrape Webpage",
      description: "Get clean AI-friendly data from any website with our web scraper."
    },
    {
      icon: <Image className="w-6 h-6 text-blue-500" />,
      iconBg: "#e0e7ff",
      title: "Screenshot URL",
      description: "Screenshot any webpage. Full page screenshots, block ads, and more."
    },
    {
      icon: <PlaySquare className="w-6 h-6 text-green-500" />,
      iconBg: "#d1fae5",
      title: "Extract Web Data",
      description: "We use multimodal LLMs to help you extract structured data from any URL."
    },
    {
      icon: <Code className="w-6 h-6 text-purple-500" />,
      iconBg: "#ede9fe",
      title: "Web Search",
      description: "Search the web with Google and optionally scrape the top results."
    },
    {
      icon: <Image className="w-6 h-6 text-pink-500" />,
      iconBg: "#fce7f3",
      title: "Get Autocomplete",
      description: "Retrieve Google Autocomplete suggestions for search queries."
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Nav />
      <main>
        <Hero />
        <StatsGrid />
        <BountyGrid />
        <VideoGrid 
          title="Feburary '25 Posthoc Creator Awards"
          description="The COTI WAGMI Commity found and awarded these COTI creatives who are sharing important content in the wild."
          videos={videos}
        />
        <AgentGrid />
        <CardGrid
          title="Add powerful tools to your automations in minutes"
          description="Our robust toolkit is the easiest way to add multiple new capabilities to your AI solutions."
          cards={cards}
        />
        <GlobeSection />
      </main>
    </div>
  )
}

